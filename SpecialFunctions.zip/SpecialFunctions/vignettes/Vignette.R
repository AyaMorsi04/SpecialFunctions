devtools::build_vignettes()
vignette("special_functions_usage")
devtools::check()

